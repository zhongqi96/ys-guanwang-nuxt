import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _38ec89f5 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _267e2372 = () => interopDefault(import('..\\pages\\business\\index.vue' /* webpackChunkName: "pages/business/index" */))
const _c7399cfc = () => interopDefault(import('..\\pages\\contact\\index.vue' /* webpackChunkName: "pages/contact/index" */))
const _2ee97a38 = () => interopDefault(import('..\\pages\\employ\\index.vue' /* webpackChunkName: "pages/employ/index" */))
const _64cc2ead = () => interopDefault(import('..\\pages\\manage\\index.vue' /* webpackChunkName: "pages/manage/index" */))
const _1f17227f = () => interopDefault(import('..\\pages\\news\\index.vue' /* webpackChunkName: "pages/news/index" */))
const _db19911e = () => interopDefault(import('..\\pages\\employ-detail\\employ.js' /* webpackChunkName: "pages/employ-detail/employ" */))
const _7e646b51 = () => interopDefault(import('..\\pages\\news-detail\\news.js' /* webpackChunkName: "pages/news-detail/news" */))
const _9decc1cc = () => interopDefault(import('..\\pages\\employ-detail\\_id.vue' /* webpackChunkName: "pages/employ-detail/_id" */))
const _6a90485f = () => interopDefault(import('..\\pages\\news-detail\\_id.vue' /* webpackChunkName: "pages/news-detail/_id" */))
const _4c8e90b2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _38ec89f5,
    name: "about"
  }, {
    path: "/business",
    component: _267e2372,
    name: "business"
  }, {
    path: "/contact",
    component: _c7399cfc,
    name: "contact"
  }, {
    path: "/employ",
    component: _2ee97a38,
    name: "employ"
  }, {
    path: "/manage",
    component: _64cc2ead,
    name: "manage"
  }, {
    path: "/news",
    component: _1f17227f,
    name: "news"
  }, {
    path: "/employ-detail/employ",
    component: _db19911e,
    name: "employ-detail-employ"
  }, {
    path: "/news-detail/news",
    component: _7e646b51,
    name: "news-detail-news"
  }, {
    path: "/employ-detail/:id",
    component: _9decc1cc,
    name: "employ-detail-id"
  }, {
    path: "/news-detail/:id",
    component: _6a90485f,
    name: "news-detail-id"
  }, {
    path: "/",
    component: _4c8e90b2,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decodeURIComponent(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
