import Vue from 'vue'
Vue.prototype.$imgUrl = 'https://image1.cdn.yishizongheng.com/shejian_gw'
// const IMG_URL= {
//   install(Vue){
//
//   }
// }
// Vue.use(IMG_URL);
